from flask import Flask, Response, render_template
from fyers_apiv3.FyersWebsocket import data_ws
import queue
import json

app = Flask(__name__)

message_queue = queue.Queue()

def onmessage(message):

    """
    Callback function to handle incoming messages from the FyersDataSocket WebSocket.
    """
    print("Response:", message)
    symbol = message.get('symbol')
    ltp = message.get('ltp')
    if symbol and ltp:
        message_queue.put({"symbol": symbol, "ltp": ltp})


def onerror(message):
    """
    Callback function to handle WebSocket errors.
    """
    print("Error:", message)


def onclose(message):
    """
    Callback function to handle WebSocket connection close events.
    """
    print("Connection closed:", message)


def onopen():
    """
    Callback function to subscribe to data type and symbols upon WebSocket connection.
    """
    # Specify the data type and symbols you want to subscribe to
    data_type = "SymbolUpdate"

    # Subscribe to the specified symbols and data type
    symbols = ['NSE:NIFTYBANK-INDEX', 'NSE:NIFTY50-INDEX', 'NSE:FINNIFTY-INDEX', 'BSE:SENSEX-INDEX', 'NSE:MIDCPNIFTY-INDEX']
    fyers.subscribe(symbols=symbols, data_type=data_type)

    # Keep the socket running to receive real-time data
    fyers.keep_running()

# Load access token from a file
with open("access.txt", 'r') as r:
    access_token = r.read().strip()

# Create a FyersDataSocket instance with the provided parameters
fyers = data_ws.FyersDataSocket(
    access_token=access_token,      
    log_path="",                     
    litemode=True,                   # Lite mode disabled. Set to True if you want a lite response.
    write_to_file=False,             # Save response in a log file instead of printing it.
    reconnect=True,                  # Enable auto-reconnection to WebSocket on disconnection.
    on_connect=onopen,               # Callback function to subscribe to data upon connection.
    on_close=onclose,                # Callback function to handle WebSocket connection close events.
    on_error=onerror,                # Callback function to handle WebSocket errors.
    on_message=onmessage             # Callback function to handle incoming messages from the WebSocket.
)

# Establish a connection to the Fyers WebSocket
fyers.connect()

@app.route('/')
def index():
    return render_template('t1.html')

@app.route('/stream')
def stream():
    def event_stream():
        while True:
            message = message_queue.get()
            yield f"data: {json.dumps(message)}\n\n"

    return Response(event_stream(), content_type='text/event-stream')

if __name__ == "__main__":
    app.run(debug=True)