
from fyers_apiv3 import fyersModel
import os
import pandas as pd
import sqlite3

with open("access.txt",'r') as r:
    access_token=r.read()

client_id = "V93AXT1M3E-100"
fyers = fyersModel.FyersModel(token=access_token, log_path=os.getcwd(),client_id=client_id) 
data = {
    "symbol":"NSE:NIFTYBANK-INDEX",
    "resolution":"1",
    "date_format":"1",
    "range_from":"2023-07-18",
    "range_to":"2024-07-18",
    "cont_flag":"1"
        }

sdata = fyers.history(data)
sdata

sdata=pd.DataFrame(sdata['candles'])
sdata.columns=['date', 'open', 'high', 'low','close', 'volume']
sdata['date'] = pd.to_datetime(sdata['date'] , unit='s')
sdata.date=(sdata.date.dt.tz_localize('UTC').dt.tz_convert('Asia/Kolkata'))
sdata['date'] = sdata['date'].dt.tz_localize(None)
sdata=sdata.set_index('date')
print(sdata)
"""
sdata = sdata[~sdata.index.duplicated(keep='first')]
#Database code
conn = sqlite3.connect('sprii.db')
cursor = conn.cursor()

# Create table if not exists
cursor.execute('''
    CREATE TABLE IF NOT EXISTS stock_data (
        date TEXT PRIMARY KEY,
        open REAL,
        high REAL,
        low REAL,
        close REAL,
        volume INTEGER
    )
''')
sdata.to_sql('stock_data', conn, if_exists='append', index=True)

conn.commit()
conn.close()

print("Data successfully loaded into SQLite database.")
"""
