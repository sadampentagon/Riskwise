""""
import time
import datetime
from fyers_apiv3 import fyersModel

client_id = "V93AXT1M3E-100"
# Load access token from a file
with open("access.txt", 'r') as r:
    access_token = r.read().strip()

# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, token=access_token, is_async=False, log_path="")

# Function to print "Hello, World!" and place an order at a specified time
def print_at_time(target_hour, target_minute, target_second):
    # Get the current time
    now = datetime.datetime.now()
    # Define the target time for today
    target_time = now.replace(hour=target_hour, minute=target_minute, second=target_second, microsecond=0)
    
    # If the target time has already passed today, set it for the next day
    if now > target_time:
        target_time += datetime.timedelta(days=1)
    
    # Calculate the number of seconds to wait
    wait_seconds = (target_time - now).total_seconds()
    
    # Wait until the target time
    print(f"Waiting for {wait_seconds} seconds...")
    time.sleep(wait_seconds)
    
    # Print "Hello, World!" at the target time
    print("Hello, World!")
    
    # Define the order data
    order_data = {
        "symbol": "NSE:IDEA-EQ",
        "qty": 1,
        "type": 3,
        "side": 1,
        "productType": "CNC",
        "limitPrice": 0,
        "stopPrice": 16.2,
        "validity": "DAY",
        "disclosedQty": 0,
        "offlineOrder": False,
        "orderTag": "tag1"
    }
    
    # Place the order
    try:
        response = fyers.place_order(data=order_data)
        print(f"Order Response: {response}")
    except Exception as e:
        print(f"Failed to place order: {e}")

# Set the target time (e.g., 13:20:59 or 1:20:59 PM)
print_at_time(target_hour=15, target_minute=14, target_second=0)
"""""
import time
import datetime
from fyers_apiv3 import fyersModel

client_id = "V93AXT1M3E-100"
# Load access token from a file
with open("access.txt", 'r') as r:
    access_token = r.read().strip()

# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, token=access_token, is_async=False, log_path="")

# Function to print "Hello, World!" and place an order at a specified time
def print_at_time(target_hour, target_minute, target_second):
    # Get the current time
    now = datetime.datetime.now()
    # Define the target time for today
    target_time = now.replace(hour=target_hour, minute=target_minute, second=target_second, microsecond=0)
    
    # If the target time has already passed today, set it for the next day
    if now > target_time:
        target_time += datetime.timedelta(days=1)
    
    # Calculate the number of seconds to wait
    wait_seconds = (target_time - now).total_seconds()
    
    # Wait until the target time
    print(f"Waiting for {wait_seconds} seconds...")
    time.sleep(wait_seconds)
    
    # Print "Hello, World!" at the target time
    print("Hello, World!")
    
    # Define the buy order data
    buy_order_data = {
        "symbol": "NSE:IDEA-EQ",
        "qty": 1,
        "type": 2,
        "side": 1,
        "productType": "CNC",
        "limitPrice": 0,
        "stopPrice": 0,
        "validity": "DAY",
        "disclosedQty": 0,
        "offlineOrder": False,
        "orderTag": "tag1"
    }
    
    # Place the buy order
    try:
        response = fyers.place_order(data=buy_order_data)
        print(f"Buy Order Response: {response}")
    except Exception as e:
        print(f"Failed to place buy order: {e}")
    
    # Wait for 1 minute (60 seconds)
    print("Waiting for 1 minute before placing sell order...")
    time.sleep(60)
    
    # Define the sell order data
    sell_order_data = {
        "symbol": "NSE:IDEA-EQ",
        "qty": 1,
        "type": 2,
        "side": -1,  # -1 for selling
        "productType": "CNC",
        "limitPrice": 0,
        "stopPrice": 0,
        "validity": "DAY",
        "disclosedQty": 0,
        "offlineOrder": False,
        "orderTag": "tag2"
    }
    
    # Place the sell order
    try:
        response = fyers.place_order(data=sell_order_data)
        print(f"Sell Order Response: {response}")
    except Exception as e:
        print(f"Failed to place sell order: {e}")

# Set the target time (e.g., 13:20:59 or 1:20:59 PM)
print_at_time(target_hour=15, target_minute=18, target_second=37)