from fyers_apiv3 import fyersModel
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
db = SQLAlchemy(app)

import os
import pandas as pd

with open("access.txt",'r') as r:
    access_token=r.read()

client_id = "V93AXT1M3E-100"
fyers = fyersModel.FyersModel(token=access_token, log_path=os.getcwd(),client_id=client_id) 

data = {
    "symbol":"NSE:NIFTYBANK-INDEX",
    "resolution":"1",
    "date_format":"1",
    "range_from":"2024-07-16",
    "range_to":"2024-07-16",
    "cont_flag":"1"
}

sdata = fyers.history(data)
#(sdata)

sdata=pd.DataFrame(sdata['candles'])
sdata.columns=['date', 'open', 'high', 'low','close', 'volume']
sdata['date'] = pd.to_datetime(sdata['date'] , unit='s')
sdata.date=(sdata.date.dt.tz_localize('UTC').dt.tz_convert('Asia/Kolkata'))
sdata['date'] = sdata['date'].dt.tz_localize(None)
sdata=sdata.set_index('date')
print(sdata)

"""
from flask import Flask, jsonify, render_template, request
from fyers_apiv3 import fyersModel
import os
import pandas as pd
import sqlite3 as sql

app = Flask(__name__)

# Function to fetch candles data
def fetch_candles_data(symbol1):
    # Read access token
    with open("access.txt", 'r') as r:
        access_token = r.read()

    client_id = "V93AXT1M3E-100"
    fyers = fyersModel.FyersModel(token=access_token, log_path=os.getcwd(), client_id=client_id)

    # Define data parameters
    data = {
        "symbol": symbol1,
        "resolution": "1",
        "date_format": "1",
        "range_from": "2024-07-18",
        "range_to": "2024-07-18",
        "cont_flag": "1"
    }

    # Fetch historical data
sdata = fyers.history(data)
return sdata
#sdata = fyers.history(data)


sdata=pd.DataFrame(sdata['candles'])
sdata.columns=['date', 'open', 'high', 'low','close', 'volume']
sdata['date'] = pd.to_datetime(sdata['date'] , unit='s')
sdata.date=(sdata.date.dt.tz_localize('UTC').dt.tz_convert('Asia/Kolkata'))
sdata['date'] = sdata['date'].dt.tz_localize(None)
sdata=sdata.set_index('date')
print(sdata)

@app.route('/', methods=['GET', 'POST'])
def index():
    selected_option = None
    candles_data = None
    error_message = None

    if request.method == 'POST':
        instrument = request.form.get('options')
        selected_option = instrument

        if instrument == 'Nifty':
            symbol1 = "NSE:NIFTY50-INDEX"
            db_name = 'nifty.db'
        elif instrument == 'BankNifty':
            symbol1 = "NSE:NIFTYBANK-INDEX"
            db_name = 'banknifty.db'
        elif instrument == 'Finfity':
            symbol1 = "NSE:FINNIFTY-INDEX"
            db_name = 'finfity.db'
        elif instrument == 'MidcapNifty':
            symbol1 = "NSE:MIDCPNIFTY-INDEX"
            db_name = 'midcapnifty.db'
        elif instrument == 'Sensex':
            symbol1 = "BSE:SENSEX-INDEX"
            db_name = 'sensex.db'
        else:
            symbol1 = None
            db_name = None

        if symbol1 and db_name:
            sdata = fetch_candles_data(symbol1)
            if 'candles' in sdata:
                candles_data = pd.DataFrame(sdata['candles'])
                candles_data.columns = ['date', 'open', 'high', 'low', 'close', 'volume']
                candles_data['date'] = pd.to_datetime(candles_data['date'], unit='s')
                candles_data.date = candles_data.date.dt.tz_localize('UTC').dt.tz_convert('Asia/Kolkata')
                candles_data['date'] = candles_data['date'].dt.tz_localize(None)
                candles_data = candles_data.set_index('date')

                # Remove duplicated indices
                candles_data = candles_data[~candles_data.index.duplicated(keep='first')]

                # Connect to the appropriate SQLite database
                conn = sql.connect(db_name)
                cursor = conn.cursor()

                # Create table if not exists
                cursor.execute(f'''
                    CREATE TABLE IF NOT EXISTS {instrument.lower()}_data (
                        date TEXT PRIMARY KEY,
                        open REAL,
                        high REAL,
                        low REAL,
                        close REAL,
                        volume INTEGER
                    )
                ''')

                # Load data into SQLite
                candles_data.to_sql(f'{instrument.lower()}_data', conn, if_exists='append', index=True)

                # Commit changes and close connection
                conn.commit()
                conn.close()
            else:
                error_message = "Error: The key 'candles' does not exist in the API response."
        else:
            error_message = "Invalid instrument selected."

    options = ["Nifty", "BankNifty", "Finfity", "MidcapNifty", "Sensex"]
    return render_template('index.html', options=options, selected_option=selected_option, candles_data=candles_data, error_message=error_message)

@app.route('/process', methods=['POST'])
def process():
    selected_instrument = request.form['instrument']
    instruments = {
        'Nifty': {'symbol': "NSE:NIFTY50-INDEX", 'db_name': 'nifty.db'},
        'BankNifty': {'symbol': "NSE:NIFTYBANK-INDEX", 'db_name': 'banknifty.db'},
        'Finfity': {'symbol': "NSE:FINNIFTY-INDEX", 'db_name': 'finfity.db'},
        'MidcapNifty': {'symbol': "NSE:MIDCPNIFTY-INDEX", 'db_name': 'midcapnifty.db'},
        'Sensex': {'symbol': "BSE:SENSEX-INDEX", 'db_name': 'sensex.db'}
    }
    instrument_info = instruments[selected_instrument]
    # Do something with instrument_info (e.g., symbol1 = instrument_info['symbol'])
    return jsonify(instrument_info)
"""
if __name__ == '__main__':
    app.run(debug=True)
