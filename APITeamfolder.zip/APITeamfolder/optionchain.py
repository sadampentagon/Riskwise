"""from flask import Flask, render_template
from fyers_apiv3 import fyersModel
import json

app = Flask(__name__)

client_id = "V93AXT1M3E-100"
# Load access token from a file
with open("access.txt", 'r') as r:
    access_token = r.read().strip()

# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, token=access_token, is_async=False, log_path="")

@app.route('/')
def index():
    data = {
        "symbol": "NSE:NIFTY50-INDEX",
        "strikecount": 5,
        "timestamp": ""
    }
   
    response = fyers.optionchain(data=data)
  
    print("Full Response:", json.dumps(response, indent=2))

    # Extract the option chain data
    option_chain_data = response.get('data', {}).get('optionsChain', [])

    return render_template('optionchain.html', data=option_chain_data)

if __name__ == "__main__":
    app.run(debug=True)
"""
from flask import Flask, render_template
from fyers_apiv3 import fyersModel
import json

app = Flask(__name__)

client_id = "V93AXT1M3E-100"
# Load access token from a file
with open("access.txt", 'r') as r:
    access_token = r.read().strip()

# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, token=access_token, is_async=False, log_path="")

@app.route('/')
def index():
    data = {
        "symbol": "NSE:NIFTY50-INDEX",
        "strikecount": 5,
        "timestamp": ""
    }
   
    response = fyers.optionchain(data=data)
  
    print("Full Response:", json.dumps(response, indent=2))

    # Extract the option chain data
    option_chain_data = response.get('data', {}).get('optionsChain', [])

    # Separate data based on option_type
    pe_data = [item for item in option_chain_data if item['option_type'] == 'PE']
    ce_data = [item for item in option_chain_data if item['option_type'] == 'CE']

    return render_template('optionchain.html', pe_data=pe_data, ce_data=ce_data)

if __name__ == "__main__":
    app.run(debug=True)
