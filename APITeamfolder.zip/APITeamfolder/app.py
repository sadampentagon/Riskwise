from flask import Flask, render_template, Response
from fyers_apiv3.FyersWebsocket import data_ws
import json
import threading

app = Flask(__name__)
ltp_data = {"ltp": "Loading..."}

def onmessage(message):
    global ltp_data
    data = json.loads(message)
    if data['type'] == 'if' and data['symbol'] == 'NSE:MIDCPNIFTY-INDEX':
        ltp_data['ltp'] = data['ltp']

def onerror(message):
    print("Error:", message)

def onclose(message):
    print("Connection closed:", message)

def onopen():
    data_type = "SymbolUpdate"
    symbols = ["NSE:NIFTYBANK-INDEX", "NSE:NIFTY50-INDEX", "NSE:FINNIFTY-INDEX", "BSE:SENSEX-INDEX", "NSE:MIDCPNIFTY-INDEX"]
    fyers.subscribe(symbols=symbols, data_type=data_type)
    fyers.keep_running()

with open("access.txt",'r') as r:
    access_token = r.read()

fyers = data_ws.FyersDataSocket(
    access_token=access_token,
    log_path="",
    litemode=True,
    write_to_file=False,
    reconnect=True,
    on_connect=onopen,
    on_close=onclose,
    on_error=onerror,
    on_message=onmessage
)

def run_websocket():
    fyers.connect()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/stream')
def stream():
    def event_stream():
        while True:
            yield f"data: {ltp_data['ltp']}\n\n"
    return Response(event_stream(), content_type='text/event-stream')

if __name__ == '__main__':
    websocket_thread = threading.Thread(target=run_websocket)
    websocket_thread.start()
    app.run(debug=True, threaded=True)
