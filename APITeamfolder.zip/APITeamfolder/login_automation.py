from fyers_apiv3 import fyersModel

client_id = "V93AXT1M3E-100"
secret_key = "1VBSFLDXWS"
redirect_uri = "https://www.google.com/"
response_type = "code"
state = "sample"
grant_type = "authorization_code"

# Import the required module from the fyers_apiv3 package



# Create a session model with the provided credentials
session = fyersModel.SessionModel(
    client_id=client_id,
    secret_key=secret_key,
    redirect_uri=redirect_uri,
    response_type=response_type
)

# Generate the auth code using the session model
response = session.generate_authcode()

# Print the auth code received in the response
print(response)



