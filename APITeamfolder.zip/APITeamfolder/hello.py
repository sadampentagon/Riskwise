"""from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
"""
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    instruments = [
        {'name': 'Nifty', 'symbol': 'NSE:NIFTY50-INDEX', 'db_name': 'nifty.db'},
        {'name': 'BankNifty', 'symbol': 'NSE:NIFTYBANK-INDEX', 'db_name': 'banknifty.db'},
        {'name': 'Finfity', 'symbol': 'NSE:FINNIFTY-INDEX', 'db_name': 'finfity.db'},
        {'name': 'MidcapNifty', 'symbol': 'NSE:MIDCPNIFTY-INDEX', 'db_name': 'midcapnifty.db'},
        {'name': 'Sensex', 'symbol': 'BSE:SENSEX-INDEX', 'db_name': 'sensex.db'}
    ]
    return render_template('index.html', instruments=instruments)

if __name__ == '__main__':
    app.run(debug=True)
